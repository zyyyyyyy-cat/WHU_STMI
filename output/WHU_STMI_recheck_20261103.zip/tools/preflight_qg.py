"""A few real CUDA/AMP training steps and masked eval forwards before a long run.

Uses the existing loaders, model, losses, optimizer and NCCL setup. Does not save
training weights or modify train.py. Supports python and torchrun entrypoints.
"""
import argparse
import json
from pathlib import Path
import sys

import torch
import torch.distributed as dist

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from config import cfg
from datasets import make_dataloader
from loss import make_loss
from model import make_model
from processor.processor import PCA, GPD, PrototypeBank, mask_kwargs
from solver import make_optimizer
from solver.scheduler_factory import create_scheduler
from train import setup_cuda_visible_devices, init_distributed, set_seed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config_file', default='configs/UAD.yml')
    parser.add_argument('--steps', type=int, default=2)
    parser.add_argument('--report', default='logs/qg_preflight.json')
    parser.add_argument('--local_rank', '--local-rank', type=int, default=-1)
    parser.add_argument('opts', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.steps < 1:
        parser.error('--steps must be positive')
    config = cfg.clone()
    config.merge_from_file(args.config_file)
    config.merge_from_list(args.opts)
    config.freeze()
    if not config.MODEL.QG_SFM.ENABLED:
        raise ValueError('This preflight checks the enabled QG-SFM experiment')
    setup_cuda_visible_devices(config)
    if not torch.cuda.is_available():
        raise RuntimeError('Run real-data preflight in the server clipreid CUDA environment')
    local_rank, rank, world = init_distributed(config, args)
    torch.cuda.set_device(local_rank)
    device = torch.device('cuda', local_rank)
    set_seed(config.SOLVER.SEED)
    try:
        loader, _, eval_loaders, _, classes, cameras, views = make_dataloader(config)
        model = make_model(config, classes, cameras, views).to(device)
        base = model
        for block in base.base.blocks:
            block.attn.collect_qg_stats = True
        qg = [(n,p) for n,p in base.named_parameters() if n.endswith(('.qg_alpha_raw', '.qg_beta_raw'))]
        if len(qg) != 24 or any(p.detach().item() != 0 for _,p in qg):
            raise AssertionError('Expected 24 zero-initialized modulation scalars')
        loss_fn, center = make_loss(config, classes)
        optimizer, _ = make_optimizer(config, model, center)
        scheduler = create_scheduler(config, optimizer)
        scheduler.step(1)
        if world > 1:
            model = torch.nn.parallel.DistributedDataParallel(
                model, device_ids=[local_rank], output_device=local_rank, find_unused_parameters=True)
        bank = PrototypeBank(classes, 768, momentum=config.MODEL.GPD_MOMENTUM, device=device)
        scaler = torch.cuda.amp.GradScaler()
        model.train()
        iterator = iter(loader)
        torch.cuda.reset_peak_memory_stats(device)
        records = []
        for step in range(args.steps):
            try:
                batch = next(iterator)
            except StopIteration:
                raise RuntimeError('Training loader ended before requested preflight steps')
            images, targets = [x.to(device) for x in batch[0]], batch[1].to(device)
            spatial = mask_kwargs(batch, device, training=True)
            optimizer.zero_grad()
            with torch.cuda.amp.autocast():
                score, feature, _ = model(images, **spatial)
                loss, ce, wrt = loss_fn(score, feature, targets.repeat(len(images)))
                pca, ids, centers = PCA(feature, targets, len(images), config.DATALOADER.NUM_INSTANCE)
                gpd = GPD(feature, targets, bank, ids, centers, len(images))
                if 'pca' in config.SOLVER.LOSS_TYPE:
                    loss = loss + config.MODEL.PCA_LOSS_WEIGHT * pca
                if 'gpd' in config.SOLVER.LOSS_TYPE:
                    loss = loss + gpd
            diagnostics = [block.attn.qg_stats.detach().cpu().tolist() for block in base.base.blocks]
            if not torch.isfinite(loss):
                raise AssertionError('Nonfinite AMP loss')
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            for name, parameter in qg:
                if parameter.grad is None or not torch.isfinite(parameter.grad).all():
                    raise AssertionError('Missing/nonfinite modulation gradient: {}'.format(name))
            gradient_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
            if not torch.isfinite(gradient_norm):
                raise AssertionError('Nonfinite model gradient norm; AMP step would be skipped')
            qg_grad_norm = torch.stack([p.grad.float().square() for _,p in qg]).sum().sqrt().item()
            scale_before = scaler.get_scale()
            scaler.step(optimizer)
            scaler.update()
            if scaler.get_scale() < scale_before:
                raise AssertionError('AMP skipped an optimizer step')
            bank.update(ids, centers, ddp=world>1)
            if world > 1:
                state = torch.cat([p.detach().reshape(-1) for _,p in qg] + [bank.prototypes.flatten()])
                states = [torch.empty_like(state) for _ in range(world)]
                dist.all_gather(states, state)
                for other in states[1:]:
                    torch.testing.assert_close(states[0], other, rtol=0, atol=0)
            row = dict(step=step+1, loss=loss.item(), ce=ce.item(), wrt=wrt.item(),
                       pca=pca.item(), gpd=gpd.item(), qg_gradient_norm=qg_grad_norm,
                       tuple_batch=len(targets), actual_images=sum(len(x) for x in images),
                       empty_masks=sum(int((~v.bool()).sum()) for v in spatial['valid_flags']),
                       qg_forward_stats=diagnostics)
            records.append(row)
            if rank == 0:
                print(json.dumps(row), flush=True)
        # Release the last training graph before validation to measure a useful peak.
        del score, feature, loss, ce, wrt, pca, gpd
        for block in base.base.blocks:
            block.attn.collect_qg_stats = False
        model.eval()
        if world > 1:
            for buffer in base.buffers():
                dist.broadcast(buffer, src=0)
        evaluated = []
        with torch.no_grad():
            for mode, val_loader in enumerate(eval_loaders, 1):
                if (mode-1) % world != rank:
                    continue
                batch = next(iter(val_loader))
                result = base(batch[0].to(device), mode=mode, **mask_kwargs(batch, device))
                if result.shape != (len(batch[0]), 768) or not torch.isfinite(result).all():
                    raise AssertionError('Masked evaluation output is invalid')
                evaluated.append(mode)
        if world > 1:
            dist.barrier()
        if rank == 0:
            report = dict(status='passed', world_size=world, torch_version=str(torch.__version__),
                          cuda_version=torch.version.cuda, gpu=torch.cuda.get_device_name(device),
                          steps=records, eval_modes_rank0=evaluated,
                          peak_allocated_mib=torch.cuda.max_memory_allocated(device)/1024**2,
                          qg_parameters={n:p.detach().item() for n,p in qg},
                          config=config.dump(),
                          scope='real train steps and one eval batch per modality; not complete retrieval evaluation')
            destination = Path(args.report)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(json.dumps(report, indent=2), encoding='utf-8')
            print('PASS: real CUDA/AMP preflight; report {}'.format(destination), flush=True)
    finally:
        if config.MODEL.DIST_TRAIN and dist.is_initialized():
            dist.destroy_process_group()


if __name__ == '__main__':
    main()
